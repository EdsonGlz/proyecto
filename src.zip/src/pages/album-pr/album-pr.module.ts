import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AlbumPrPage } from './album-pr';

@NgModule({
  declarations: [
    AlbumPrPage,
  ],
  imports: [
    IonicPageModule.forChild(AlbumPrPage),
  ],
})
export class AlbumPrPageModule {}
