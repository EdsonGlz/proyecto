import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LoboPage } from './lobo';

@NgModule({
  declarations: [
    LoboPage,
  ],
  imports: [
    IonicPageModule.forChild(LoboPage),
  ],
})
export class LoboPageModule {}
