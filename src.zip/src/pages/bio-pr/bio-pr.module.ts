import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BioPrPage } from './bio-pr';

@NgModule({
  declarations: [
    BioPrPage,
  ],
  imports: [
    IonicPageModule.forChild(BioPrPage),
  ],
})
export class BioPrPageModule {}
