import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AlbumRfPage } from './album-rf';

@NgModule({
  declarations: [
    AlbumRfPage,
  ],
  imports: [
    IonicPageModule.forChild(AlbumRfPage),
  ],
})
export class AlbumRfPageModule {}
