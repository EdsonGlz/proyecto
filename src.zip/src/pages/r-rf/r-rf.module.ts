import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RRfPage } from './r-rf';

@NgModule({
  declarations: [
    RRfPage,
  ],
  imports: [
    IonicPageModule.forChild(RRfPage),
  ],
})
export class RRfPageModule {}
