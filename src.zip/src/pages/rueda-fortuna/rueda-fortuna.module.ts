import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RuedaFortunaPage } from './rueda-fortuna';

@NgModule({
  declarations: [
    RuedaFortunaPage,
  ],
  imports: [
    IonicPageModule.forChild(RuedaFortunaPage),
  ],
})
export class RuedaFortunaPageModule {}
