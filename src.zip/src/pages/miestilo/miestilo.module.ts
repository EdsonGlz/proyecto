import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MiestiloPage } from './miestilo';

@NgModule({
  declarations: [
    MiestiloPage,
  ],
  imports: [
    IonicPageModule.forChild(MiestiloPage),
  ],
})
export class MiestiloPageModule {}
