import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RLdPage } from './r-ld';

@NgModule({
  declarations: [
    RLdPage,
  ],
  imports: [
    IonicPageModule.forChild(RLdPage),
  ],
})
export class RLdPageModule {}
