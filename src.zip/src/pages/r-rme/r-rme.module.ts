import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RRmePage } from './r-rme';

@NgModule({
  declarations: [
    RRmePage,
  ],
  imports: [
    IonicPageModule.forChild(RRmePage),
  ],
})
export class RRmePageModule {}
