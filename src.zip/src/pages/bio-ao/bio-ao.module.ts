import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BioAoPage } from './bio-ao';

@NgModule({
  declarations: [
    BioAoPage,
  ],
  imports: [
    IonicPageModule.forChild(BioAoPage),
  ],
})
export class BioAoPageModule {}
