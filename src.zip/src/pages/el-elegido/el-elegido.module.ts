import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ElElegidoPage } from './el-elegido';

@NgModule({
  declarations: [
    ElElegidoPage,
  ],
  imports: [
    IonicPageModule.forChild(ElElegidoPage),
  ],
})
export class ElElegidoPageModule {}
