import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AlbumEePage } from './album-ee';

@NgModule({
  declarations: [
    AlbumEePage,
  ],
  imports: [
    IonicPageModule.forChild(AlbumEePage),
  ],
})
export class AlbumEePageModule {}
