import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { REePage } from './r-ee';

@NgModule({
  declarations: [
    REePage,
  ],
  imports: [
    IonicPageModule.forChild(REePage),
  ],
})
export class REePageModule {}
